"""
GroupNova ⚡ - Telegram Group Management Bot
Main production entry point using Python 3.12+ and aiogram 3.x.
"""

import asyncio
import logging
import os
import sys

from dotenv import load_dotenv

load_dotenv()

from aiogram import Bot, Dispatcher, F, Router
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ChatType, ParseMode
from aiogram.filters import Command, CommandStart
from aiogram.types import (
    BotCommand,
    BotCommandScopeDefault,
    CallbackQuery,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    KeyboardButton,
    Message,
    ReplyKeyboardMarkup,
)

BOT_TOKEN = os.getenv("BOT_TOKEN", "").strip()
SUPPORT_URL = os.getenv("SUPPORT_URL", "https://t.me/GroupSupportHub")
GROUP_URL = os.getenv("GROUP_URL", "https://t.me/OfficialCommunityGroup")
CHANNEL_URL = os.getenv("CHANNEL_URL", "https://t.me/OfficialUpdateChannel")
PRIVACY_URL = os.getenv("PRIVACY_URL", "https://telegra.ph/Privacy-Policy-01-01")

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(name)s: %(message)s")
logger = logging.getLogger("groupnova")
router = Router(name="groupnova_main_router")


def get_start_reply_keyboard() -> ReplyKeyboardMarkup:
    return ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text="➕ Add me to a Group ➕")],
            [KeyboardButton(text="⚙️ Manage Group Settings ✍️")],
            [KeyboardButton(text="👥 Group"), KeyboardButton(text="📢 Channel")],
            [KeyboardButton(text="🚨 Support"), KeyboardButton(text="ℹ️ Information")],
            [KeyboardButton(text="🌐 Languages")],
        ],
        resize_keyboard=True,
        is_persistent=True,
    )


@router.message(CommandStart(), F.chat.type == ChatType.PRIVATE)
async def handle_start(message: Message, bot: Bot):
    bot_info = await bot.get_me()
    username = bot_info.username or "GroupNovaBot"

    text = (
        "⚡ <b>Welcome to GroupNova!</b>\n\n"
        "Your Telegram group management assistant is ready.\n\n"
        "Add GroupNova to your group to configure welcome messages and group settings."
    )

    deep_link = (
        f"https://t.me/{username}?startgroup=botstart&"
        "admin=change_info+delete_messages+restrict_members+invite_users+pin_messages"
    )

    inline_kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="➕ Add me to a Group ➕", url=deep_link)],
            [InlineKeyboardButton(text="🔒 Privacy Policy", url=PRIVACY_URL)],
        ]
    )

    await message.answer(text=text, parse_mode=ParseMode.HTML, reply_markup=get_start_reply_keyboard())
    await message.answer(text="👇 Quick action links:", reply_markup=inline_kb, disable_web_page_preview=True)


@router.message(Command("help"))
async def handle_help(message: Message):
    text = (
        "📖 <b>GroupNova Command Manual</b>\n\n"
        "<b>⚙️ Group Settings</b>\n"
        "• <code>/settings</code> - Open group configuration panel\n"
        "• <code>/welcome</code> - Check active welcome greeting\n"
        "• <code>/rules</code> - Read group guidelines\n\n"
        "<b>🛡️ Moderation Tools (Admins Only)</b>\n"
        "• <code>/warn [reason]</code> - Warn member (reply required)\n"
        "• <code>/mute [duration] [reason]</code> - Restrict user\n"
        "• <code>/unmute</code> - Restore speech\n"
        "• <code>/kick [reason]</code> - Remove user\n"
        "• <code>/ban [reason]</code> - Ban user\n"
        "• <code>/unban</code> - Unban user\n"
        "• <code>/stats</code> - View group statistics\n"
        "• <code>/id</code> - Display IDs"
    )
    await message.answer(text=text, parse_mode=ParseMode.HTML)


@router.message(F.text == "➕ Add me to a Group ➕", F.chat.type == ChatType.PRIVATE)
async def handle_btn_add_group(message: Message, bot: Bot):
    bot_info = await bot.get_me()
    username = bot_info.username or "GroupNovaBot"
    deep_link = f"https://t.me/{username}?startgroup=botstart&admin=change_info+delete_messages+restrict_members+invite_users+pin_messages"
    kb = InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="➕ Select Group to Add", url=deep_link)]])
    await message.answer("Click below to add GroupNova to your group:", parse_mode=ParseMode.HTML, reply_markup=kb)


@router.message(F.text == "⚙️ Manage Group Settings ✍️", F.chat.type == ChatType.PRIVATE)
async def handle_btn_settings(message: Message):
    await message.answer("⚙️ <b>Manage Group Settings</b>\n\nSend <code>/settings</code> inside your group to configure.", parse_mode=ParseMode.HTML)


@router.message(F.text == "👥 Group", F.chat.type == ChatType.PRIVATE)
async def handle_btn_group(message: Message):
    kb = InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="👥 Open Official Group", url=GROUP_URL)]])
    await message.answer("👥 Join our official discussion group:", parse_mode=ParseMode.HTML, reply_markup=kb)


@router.message(F.text == "📢 Channel", F.chat.type == ChatType.PRIVATE)
async def handle_btn_channel(message: Message):
    kb = InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="📢 Open Updates Channel", url=CHANNEL_URL)]])
    await message.answer("📢 Subscribe to our official updates channel:", parse_mode=ParseMode.HTML, reply_markup=kb)


@router.message(F.text == "🚨 Support", F.chat.type == ChatType.PRIVATE)
async def handle_btn_support(message: Message):
    kb = InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="🚨 Contact Support", url=SUPPORT_URL)]])
    await message.answer("🚨 Need help? Contact our support team:", parse_mode=ParseMode.HTML, reply_markup=kb)


@router.message(F.text == "ℹ️ Information", F.chat.type == ChatType.PRIVATE)
async def handle_btn_info(message: Message):
    await message.answer("ℹ️ <b>GroupNova v2.4.0</b>\nEngine: Python 3.12 + aiogram 3.x\nStatus: 🟢 Operational", parse_mode=ParseMode.HTML)


@router.message(F.text.in_({"🌐 Languages", "🌐 Languages 🌐"}), F.chat.type == ChatType.PRIVATE)
async def handle_btn_languages(message: Message):
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🇬🇧 English", callback_data="lang_select:en"),
         InlineKeyboardButton(text="🇧🇩 বাংলা (Bengali)", callback_data="lang_select:bn")]
    ])
    await message.answer("🌐 Select Language / ভাষা নির্বাচন করুন:", parse_mode=ParseMode.HTML, reply_markup=kb)


async def main():
    if not BOT_TOKEN:
        logger.error("FATAL: BOT_TOKEN is not set!")
        return
    bot = Bot(token=BOT_TOKEN, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
    dp = Dispatcher()
    dp.include_router(router)
    await bot.delete_webhook(drop_pending_updates=False)
    await dp.start_polling(bot)


if __name__ == "__main__":
    asyncio.run(main())