"""
Database layer using SQLAlchemy 2.0 with async engine (aiosqlite / asyncpg).
Stores all multi-group configuration, welcome messages, rules, moderation, and stats.
"""

from datetime import datetime
from typing import List, Optional
from sqlalchemy import (
    BigInteger, Boolean, Column, DateTime, ForeignKey,
    Integer, String, Text, select, update, delete
)
from sqlalchemy.ext.asyncio import (
    AsyncSession, async_sessionmaker, create_async_engine
)
from sqlalchemy.orm import declarative_base, relationship
from bot.config import settings

Base = declarative_base()

class User(Base):
    __tablename__ = "users"
    user_id = Column(BigInteger, primary_key=True)
    username = Column(String(255), nullable=True)
    first_name = Column(String(255), nullable=False)
    last_name = Column(String(255), nullable=True)
    language = Column(String(10), default="en")
    created_at = Column(DateTime, default=datetime.utcnow)

class Group(Base):
    __tablename__ = "groups"
    group_id = Column(BigInteger, primary_key=True)
    title = Column(String(255), nullable=False)
    username = Column(String(255), nullable=True)
    member_count = Column(Integer, default=1)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)

class GroupAdmin(Base):
    __tablename__ = "group_admins"
    id = Column(Integer, primary_key=True, autoincrement=True)
    group_id = Column(BigInteger, ForeignKey("groups.group_id", ondelete="CASCADE"), index=True)
    user_id = Column(BigInteger, ForeignKey("users.user_id", ondelete="CASCADE"), index=True)
    role = Column(String(50), default="administrator")
    can_manage_settings = Column(Boolean, default=True)

class GroupSettings(Base):
    __tablename__ = "group_settings"
    group_id = Column(BigInteger, ForeignKey("groups.group_id", ondelete="CASCADE"), primary_key=True)
    language = Column(String(10), default="en")

class WelcomeTemplate(Base):
    __tablename__ = "welcome_templates"
    group_id = Column(BigInteger, ForeignKey("groups.group_id", ondelete="CASCADE"), primary_key=True)
    is_enabled = Column(Boolean, default=True)
    template_text = Column(Text, default="👋 Welcome {first_name} to <b>{group_name}</b>!\n\nGlad to have you with us. Please check the /rules and have fun!")
    delete_after_seconds = Column(Integer, default=0)

class WelcomeButton(Base):
    __tablename__ = "welcome_buttons"
    id = Column(Integer, primary_key=True, autoincrement=True)
    group_id = Column(BigInteger, ForeignKey("groups.group_id", ondelete="CASCADE"), index=True)
    label = Column(String(100), nullable=False)
    url = Column(String(500), nullable=False)
    row_index = Column(Integer, default=0)
    order_index = Column(Integer, default=0)

class GroupRule(Base):
    __tablename__ = "group_rules"
    group_id = Column(BigInteger, ForeignKey("groups.group_id", ondelete="CASCADE"), primary_key=True)
    rules_text = Column(Text, default="1. Be respectful to everyone.\n2. No spam or unauthorized advertising.")
    show_in_welcome = Column(Boolean, default=True)

class ModerationSetting(Base):
    __tablename__ = "moderation_settings"
    group_id = Column(BigInteger, ForeignKey("groups.group_id", ondelete="CASCADE"), primary_key=True)
    anti_spam = Column(Boolean, default=True)
    anti_flood = Column(Boolean, default=True)
    flood_limit_messages = Column(Integer, default=5)
    flood_limit_seconds = Column(Integer, default=5)
    link_protection = Column(Boolean, default=False)
    warn_limit = Column(Integer, default=3)
    warn_action = Column(String(20), default="mute")
    mute_duration_minutes = Column(Integer, default=60)

class Warning(Base):
    __tablename__ = "warnings"
    id = Column(Integer, primary_key=True, autoincrement=True)
    group_id = Column(BigInteger, ForeignKey("groups.group_id", ondelete="CASCADE"), index=True)
    user_id = Column(BigInteger, ForeignKey("users.user_id", ondelete="CASCADE"), index=True)
    reason = Column(String(255), default="Rule violation")
    issued_by = Column(BigInteger, nullable=False)
    issued_at = Column(DateTime, default=datetime.utcnow)

engine = create_async_engine(settings.database_url, echo=False)
async_session = async_sessionmaker(bind=engine, class_=AsyncSession, expire_on_commit=False)

async def init_db():
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)