"""
Configuration module for Telegram Group Management Bot.
Loads environment variables safely using Pydantic Settings.
"""

from typing import Optional
from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    bot_token: str = Field(default="YOUR_BOT_TOKEN_HERE", alias="BOT_TOKEN")
    owner_id: int = Field(default=0, alias="OWNER_ID")
    database_url: str = Field(default="sqlite+aiosqlite:///./bot_database.db", alias="DATABASE_URL")
    redis_url: Optional[str] = Field(default=None, alias="REDIS_URL")
    webhook_url: Optional[str] = Field(default=None, alias="WEBHOOK_URL")
    webhook_path: str = Field(default="/webhook", alias="WEBHOOK_PATH")
    web_server_host: str = Field(default="0.0.0.0", alias="WEB_SERVER_HOST")
    web_server_port: int = Field(default=8080, alias="WEB_SERVER_PORT")
    gemini_api_key: Optional[str] = Field(default=None, alias="GEMINI_API_KEY")
    openai_api_key: Optional[str] = Field(default=None, alias="OPENAI_API_KEY")
    support_url: str = Field(default="https://t.me/GroupSupportHub", alias="SUPPORT_URL")
    group_url: str = Field(default="https://t.me/OfficialCommunityGroup", alias="GROUP_URL")
    channel_url: str = Field(default="https://t.me/OfficialUpdateChannel", alias="CHANNEL_URL")
    privacy_url: str = Field(default="https://telegra.ph/Privacy-Policy-01-01", alias="PRIVACY_URL")
    default_language: str = Field(default="en", alias="DEFAULT_LANGUAGE")
    log_level: str = Field(default="INFO", alias="LOG_LEVEL")

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore"
    )


settings = Settings()