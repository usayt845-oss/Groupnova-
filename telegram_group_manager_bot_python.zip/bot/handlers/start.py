"""
Start handler and private chat interaction router.
Supports public self-service usage, deep link group configuration, and language switching.
"""

from aiogram import Bot, F, Router
from aiogram.filters import Command, CommandObject, CommandStart
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message
from sqlalchemy import select, update
from bot.config import settings
from bot.database import User, Group, GroupAdmin, async_session
from bot.keyboards.start import get_add_to_group_inline_keyboard, get_language_inline_keyboard, get_start_reply_keyboard
from bot.keyboards.settings import get_group_selection_keyboard, get_main_settings_keyboard
from bot.utils.formatting import get_text
from bot.utils.permissions import can_user_manage_group

router = Router(name="start_router")

@router.message(CommandStart(), F.chat.type == "private")
async def handle_start_private(message: Message, bot: Bot, command: CommandObject, state: FSMContext):
    await state.clear()
    
    # Handle deep link for group settings: /start settings_<group_id>
    if command.args and command.args.startswith("settings_"):
        try:
            target_group_id = int(command.args.replace("settings_", ""))
            if await can_user_manage_group(bot, target_group_id, message.from_user.id):
                async with async_session() as session:
                    stmt = select(Group).where(Group.group_id == target_group_id)
                    res = await session.execute(stmt)
                    group = res.scalar_one_or_none()

                group_title = group.title if group else f"Group {target_group_id}"
                kb = get_main_settings_keyboard(target_group_id)
                await message.answer(f"⚙️ <b>Group Settings: {group_title}</b>", parse_mode="HTML", reply_markup=kb)
                return
            else:
                await message.answer("⛔ <b>Permission Denied</b>\nYou must be an administrator in that group.", parse_mode="HTML")
                return
        except Exception:
            pass

    welcome_text = get_text("welcome_start", lang="en", privacy_url=settings.privacy_url)
    reply_kb = get_start_reply_keyboard(lang="en")
    await message.answer(text=welcome_text, parse_mode="HTML", reply_markup=reply_kb, disable_web_page_preview=True)