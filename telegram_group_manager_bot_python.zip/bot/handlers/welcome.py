"""
Welcome message handler and group join event listener.
Handles bot onboarding, required permissions guidance, and member welcomes.
"""

import html
from aiogram import Bot, F, Router
from aiogram.enums import ChatMemberStatus
from aiogram.filters import ChatMemberUpdatedFilter, Command, IS_MEMBER, IS_NOT_MEMBER
from aiogram.types import ChatMemberUpdated, InlineKeyboardButton, InlineKeyboardMarkup, Message
from sqlalchemy import select
from bot.database import (
    async_session, Group, GroupAdmin, GroupSettings,
    WelcomeTemplate, ModerationSetting, GroupRule
)
from bot.services.welcome_service import render_welcome_template, send_welcome_for_member
from bot.utils.permissions import is_chat_admin, is_group_chat

router = Router(name="welcome_router")


async def ensure_group_exists(chat, bot: Bot):
    async with async_session() as session:
        stmt = select(Group).where(Group.group_id == chat.id)
        res = await session.execute(stmt)
        group = res.scalar_one_or_none()

        if not group:
            try:
                member_count = await bot.get_chat_member_count(chat.id)
            except Exception:
                member_count = 1

            group = Group(
                group_id=chat.id,
                title=chat.title or "Untitled Group",
                username=chat.username,
                member_count=member_count,
                is_active=True
            )
            session.add(group)
            session.add(GroupSettings(group_id=chat.id))
            session.add(WelcomeTemplate(group_id=chat.id))
            session.add(GroupRule(group_id=chat.id))
            session.add(ModerationSetting(group_id=chat.id))
            await session.commit()


@router.my_chat_member()
async def handle_bot_membership_change(event: ChatMemberUpdated, bot: Bot):
    if not is_group_chat(event.chat.type):
        return

    new_status = event.new_chat_member.status
    old_status = event.old_chat_member.status
    bot_info = await bot.get_me()

    if old_status in [ChatMemberStatus.LEFT, ChatMemberStatus.KICKED] and new_status in [ChatMemberStatus.MEMBER, ChatMemberStatus.ADMINISTRATOR]:
        await ensure_group_exists(event.chat, bot)

        if event.from_user and not event.from_user.is_bot:
            async with async_session() as session:
                session.add(GroupAdmin(group_id=event.chat.id, user_id=event.from_user.id, role="creator", can_manage_settings=True))
                await session.commit()

        is_admin = new_status == ChatMemberStatus.ADMINISTRATOR
        settings_deep_link = f"https://t.me/{bot_info.username}?start=settings_{event.chat.id}"
        kb = InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="⚙️ Configure Group Settings", url=settings_deep_link)],
            [InlineKeyboardButton(text="📜 View Default Rules", callback_data=f"read_rules:{event.chat.id}")]
        ])

        if not is_admin:
            text = (
                "👋 <b>Group Management Bot Activated!</b>\n\n"
                f"Thank you for adding me to <b>{html.escape(event.chat.title or 'the group')}</b>!\n\n"
                "⚡ <b>REQUIRED SETUP:</b>\n"
                "Please <b>promote me to Administrator</b> with:\n"
                "• <i>Delete messages</i>\n"
                "• <i>Ban / Restrict members</i>\n"
                "• <i>Pin messages</i>\n\n"
                "👉 Group administrators can click below or type /settings to configure!"
            )
        else:
            text = (
                "✅ <b>Administrator Permissions Confirmed!</b>\n\n"
                f"I am now actively protecting <b>{html.escape(event.chat.title or 'this group')}</b>.\n"
                "All moderation shields and Welcome greetings are active."
            )

        try:
            await bot.send_message(chat_id=event.chat.id, text=text, parse_mode="HTML", reply_markup=kb)
        except Exception:
            pass


@router.chat_member(ChatMemberUpdatedFilter(member_status_changed=IS_NOT_MEMBER >> IS_MEMBER))
async def handle_new_chat_member(event: ChatMemberUpdated, bot: Bot):
    if not is_group_chat(event.chat.type):
        return
    bot_info = await bot.get_me()
    if event.new_chat_member.user.id == bot_info.id:
        return

    await ensure_group_exists(event.chat, bot)
    try:
        count = await bot.get_chat_member_count(event.chat.id)
    except Exception:
        count = 1

    await send_welcome_for_member(bot=bot, chat=event.chat, user=event.new_chat_member.user, member_count=count)