"""
Permission verification utilities for administrators, chat creators, and bot owner.
Validates Telegram getChatMember API and ensures multi-tenant group isolation.
"""

from aiogram import Bot
from aiogram.enums import ChatMemberStatus, ChatType
from sqlalchemy import select
from bot.config import settings
from bot.database import async_session, GroupAdmin

def is_owner(user_id: int) -> bool:
    return settings.owner_id != 0 and user_id == settings.owner_id

async def is_chat_admin(bot: Bot, chat_id: int, user_id: int) -> bool:
    if is_owner(user_id):
        return True
    try:
        member = await bot.get_chat_member(chat_id=chat_id, user_id=user_id)
        is_adm = member.status in [ChatMemberStatus.CREATOR, ChatMemberStatus.ADMINISTRATOR]
        if is_adm:
            async with async_session() as session:
                stmt = select(GroupAdmin).where(GroupAdmin.group_id == chat_id, GroupAdmin.user_id == user_id)
                res = await session.execute(stmt)
                if not res.scalar_one_or_none():
                    session.add(GroupAdmin(group_id=chat_id, user_id=user_id, role="administrator", can_manage_settings=True))
                    await session.commit()
        return is_adm
    except Exception:
        return False

async def can_user_manage_group(bot: Bot, chat_id: int, user_id: int) -> bool:
    return await is_chat_admin(bot, chat_id, user_id)

def is_group_chat(chat_type: str) -> bool:
    return chat_type in [ChatType.GROUP, ChatType.SUPERGROUP, "group", "supergroup"]