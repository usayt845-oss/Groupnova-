"""
Inline keyboards for GroupNova Group Settings Dashboard and sub-menus.
Matches the GroupNova interactive layout with dedicated submenus for each module.
"""

from typing import List, Optional
from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup
from bot.database import Group, WelcomeButton


def get_group_selection_keyboard(groups: List[Group]) -> InlineKeyboardMarkup:
    """Keyboard listing all groups the user administers."""
    keyboard = []
    for g in groups:
        keyboard.append([
            InlineKeyboardButton(
                text=f"📁 {g.title}",
                callback_data=f"manage_group:{g.group_id}"
            )
        ])
    keyboard.append([
        InlineKeyboardButton(text="🔄 Refresh List", callback_data="refresh_group_list"),
        InlineKeyboardButton(text="➕ Add New Group", callback_data="cmd_add_group")
    ])
    return InlineKeyboardMarkup(inline_keyboard=keyboard)


def get_main_settings_keyboard(group_id: int) -> InlineKeyboardMarkup:
    """
    Main GroupNova Settings Dashboard inline keyboard:
    ⚙️ GroupNova Settings
    [👋 Welcome Settings]
    [🔘 Welcome Buttons]
    [📜 Group Rules]
    [🛡️ Anti-Spam]
    [🌊 Anti-Flood]
    [🔗 Link Protection]
    [⚠️ Warning System]
    [👮 Moderation Tools]
    [📊 Group Statistics]
    [🌐 Language Settings]
    [⬅️ Back]
    """
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="👋 Welcome Settings", callback_data=f"set_welc:{group_id}")],
        [InlineKeyboardButton(text="🔘 Welcome Buttons", callback_data=f"set_btns:{group_id}")],
        [InlineKeyboardButton(text="📜 Group Rules", callback_data=f"set_rules:{group_id}")],
        [
            InlineKeyboardButton(text="🛡️ Anti-Spam", callback_data=f"set_spam:{group_id}"),
            InlineKeyboardButton(text="🌊 Anti-Flood", callback_data=f"set_flood:{group_id}")
        ],
        [
            InlineKeyboardButton(text="🔗 Link Protection", callback_data=f"set_links:{group_id}"),
            InlineKeyboardButton(text="⚠️ Warning System", callback_data=f"set_warns:{group_id}")
        ],
        [InlineKeyboardButton(text="👮 Moderation Tools", callback_data=f"set_adm:{group_id}")],
        [InlineKeyboardButton(text="📊 Group Statistics", callback_data=f"set_stats:{group_id}")],
        [InlineKeyboardButton(text="🌐 Language Settings", callback_data=f"set_lang_grp:{group_id}")],
        [InlineKeyboardButton(text="⬅️ Back", callback_data="back_to_groups")]
    ])