"""
Main entry point for the Telegram Group Management Bot.
Supports both Long Polling and Webhook modes for public multi-group production deployment.
"""

import argparse
import asyncio
import sys
from aiohttp import web
from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.types import BotCommand, BotCommandScopeDefault
from aiogram.webhook.aiohttp_server import SimpleRequestHandler, setup_application
from loguru import logger

from bot.config import settings
from bot.database import init_db
from bot.handlers import moderation, owner, rules, settings as settings_handler, start, welcome
from bot.middlewares.throttling import ThrottlingMiddleware


async def set_bot_commands(bot: Bot):
    """Sets standard commands in the Telegram menu button."""
    commands = [
        BotCommand(command="start", description="Start bot / Open main menu"),
        BotCommand(command="help", description="Show full command guide & manual"),
        BotCommand(command="settings", description="Open Group Settings Dashboard"),
        BotCommand(command="welcome", description="Check welcome message status"),
        BotCommand(command="rules", description="View group guidelines & rules"),
        BotCommand(command="warn", description="Warn member (reply required)"),
        BotCommand(command="mute", description="Mute member (reply required)"),
        BotCommand(command="kick", description="Kick member (reply required)"),
        BotCommand(command="ban", description="Ban member (reply required)"),
        BotCommand(command="unban", description="Unban member (reply required)"),
        BotCommand(command="id", description="Show chat & user IDs"),
        BotCommand(command="cancel", description="Cancel current operation")
    ]
    await bot.set_my_commands(commands, scope=BotCommandScopeDefault())


def create_dispatcher() -> Dispatcher:
    dp = Dispatcher(storage=MemoryStorage())
    dp.message.middleware(ThrottlingMiddleware(rate_limit=0.5))
    dp.include_router(start.router)
    dp.include_router(settings_handler.router)
    dp.include_router(welcome.router)
    dp.include_router(rules.router)
    dp.include_router(moderation.router)
    dp.include_router(owner.router)
    return dp


async def run_polling(bot: Bot, dp: Dispatcher):
    try:
        await set_bot_commands(bot)
        bot_info = await bot.get_me()
        logger.info(f"Public Bot started in POLLING mode: @{bot_info.username}")
        logger.info(f"Public Add Link: https://t.me/{bot_info.username}?startgroup=botstart&admin=change_info+delete_messages+restrict_members+invite_users+pin_messages")
        await bot.delete_webhook(drop_pending_updates=True)
        await dp.start_polling(bot)
    except Exception as e:
        logger.error(f"Runtime error in polling mode: {e}")
    finally:
        await bot.session.close()


def run_webhook(bot: Bot, dp: Dispatcher):
    if not settings.webhook_url:
        logger.error("WEBHOOK_URL is not set!")
        return

    full_webhook_url = f"{settings.webhook_url.rstrip('/')}{settings.webhook_path}"

    async def on_startup(app: web.Application):
        await set_bot_commands(bot)
        bot_info = await bot.get_me()
        logger.info(f"Starting in WEBHOOK mode: @{bot_info.username} -> {full_webhook_url}")
        await bot.set_webhook(url=full_webhook_url, drop_pending_updates=True)

    async def on_shutdown(app: web.Application):
        await bot.delete_webhook()
        await bot.session.close()

    app = web.Application()
    app.on_startup.append(on_startup)
    app.on_shutdown.append(on_shutdown)
    SimpleRequestHandler(dispatcher=dp, bot=bot).register(app, path=settings.webhook_path)
    setup_application(app, dp, bot=bot)
    web.run_app(app, host=settings.web_server_host, port=settings.web_server_port)


async def main():
    parser = argparse.ArgumentParser(description="Public Telegram Group Management Bot")
    parser.add_argument("--webhook", action="store_true", help="Run in webhook mode")
    args = parser.parse_args()

    logger.remove()
    logger.add(sys.stdout, level=settings.log_level)
    await init_db()

    bot = Bot(token=settings.bot_token, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
    dp = create_dispatcher()

    if args.webhook or settings.webhook_url:
        run_webhook(bot, dp)
    else:
        await run_polling(bot, dp)


if __name__ == "__main__":
    asyncio.run(main())